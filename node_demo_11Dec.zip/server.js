var express = require('express');
var bodyParser = require('body-parser');
var express = require('express');
var login = require('./Routes/loginroutes');
var allusers = require('./Routes/getAllusers');
var singleuser = require('./Routes/singleuser');
var app = express();
var router = express.Router();

var app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

// test route
router.get('/', function(req, res) {
    res.json({ message: 'welcome to our upload module api' });  
});

// http://localhost:5000/api/login :: POST
router.post('/login', login.login);
router.get('/getallusers',allusers.getallusers);
router.post('/singleuser',singleuser.singleuser);
app.use('/api', router);
app.listen(5000);

module.exports = app;