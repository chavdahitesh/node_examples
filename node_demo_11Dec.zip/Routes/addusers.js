var connection = require('../db_connect');

module.exports.adduser = function(req,res){

};