var db = require('../db_connect');

module.exports.singleuser = function(res,req){
    let user_id = req.params.id;
    if(!user_id){
        return res.status(400).send({
            error:true,
            message:'Please provide user_id'
        });
    }
    db.query('select * from users where id=?',[user_id],function(error,fields,results){
        if (error) throw error;
       return res.send({ error: false, data: results[0], message: 'users list.' });

    });
}