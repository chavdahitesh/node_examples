var db = require('../db_connect');

module.exports.getallusers =function(req,res){
    db.query('select * from users',function(error,fields,result){
        if(error) throw error;
        return res.send({
            error:false,
            data:result,
            message:'User List'
        }); 
    });
}